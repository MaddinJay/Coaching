Vrapper 0.74.0

For the full documentation visit http://vrapper.sourceforge.net/documentation .
Bug reports / feature requests: https://github.com/vrapper/vrapper/issues
Source code: https://github.com/vrapper/vrapper


Installation

In Eclipse, choose Help -> Install New Software... then click "Add" to add a new repository.  Click "Archive..." and then choose this zip file.  You should be able to install Vrapper via the zip file as if it was an online repository.

Or, put the jars in the plugin/ and features/ directories of your Eclipse installation.

There is also an update site available:
http://vrapper.sourceforge.net/update-site/stable
Usage of the update site is recommended over manual installation.


Usage

There should be a button in the toolbar (little vim icon) and an option "Toggle Vrapper" in the "Edit" menu. Just click on either of them to activate the plugins functionality. You can also define a keyboard shortcut. Go to General->Keys under the workspace preferences and type "vrapper" into the filter, then set whatever shortcut you like.
When activated, every open text editor will be wrapped by the plugin to offer vim-like behaviour.

